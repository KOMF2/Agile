package org.cvtc.shapes.test;

import static org.junit.Assert.*;

import org.junit.Test;

import cvtc.edu.java.Sphere;

public class SphereTest {

	//Variables
	Sphere sphere1 = new Sphere(1);
	
	@Test
	public void testConstructor() {
		
		assertTrue(sphere1 instanceof Sphere);
	}
	
	@Test
	public void testGetRadius() { 
		
		assertEquals(1.0, sphere1.getRadius(), 0.0);
	}
	
	@Test
	public void testGetSurfaceArea() { 
		
		assertEquals(12.566370964050293, sphere1.surfaceArea(), 0.0);
		assertNotEquals(-1.0, sphere1.surfaceArea(), 0.0);
		assertNotEquals(0.0, sphere1.surfaceArea(), 0.0);
	}

	@Test
	public void testGetVolume() { 
		
		assertEquals(3.1415927410125732, sphere1.volume(), 0.0);
		assertNotEquals(-1.0, sphere1.volume(), 0.0);
		assertNotEquals(0.0, sphere1.volume(), 0.0);
	}
}
