package org.cvtc.shapes.test;

import static org.junit.Assert.*;

import org.junit.Test;

import cvtc.edu.java.Cylinder;

public class CylinderTest {

	//Variables
	Cylinder cylinder1 = new Cylinder(1, 1);
	
	@Test
	public void testConstructor() {
		
		assertTrue(cylinder1 instanceof Cylinder);
	}
	
	@Test
	public void testGetHeight() { 
		
		assertEquals(1.0, cylinder1.getHeight(), 0.0);
	}
	
	@Test
	public void testGetRadius() { 
		
		assertEquals(1.0, cylinder1.getRadius(), 0.0);
	}
	
	@Test
	public void testGetSurfaceArea() { 
		
		assertEquals(6.2831854820251465, cylinder1.surfaceArea(), 0.0);
		assertNotEquals(-1.0, cylinder1.surfaceArea(), 0.0);
		assertNotEquals(0.0, cylinder1.surfaceArea(), 0.0);
	}
	
	@Test
	public void testGetVolume() { 
		
		assertEquals(3.1415927410125732, cylinder1.volume(), 0.0);
		assertNotEquals(-1.0, cylinder1.volume(), 0.0);
		assertNotEquals(0.0, cylinder1.volume(), 0.0);
	}

}
