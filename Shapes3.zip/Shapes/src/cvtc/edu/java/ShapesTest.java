package cvtc.edu.java;

import java.util.Scanner;

public class ShapesTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Variables
		float cuboidHeight;
		float cuboidWidth;
		float cuboidDepth;
		
		float cylinderHeight;
		float cylinderRadius;
		
		float sphereRadius;
		

		
		//Scanner Object
		Scanner keyboard = new Scanner (System.in);
		
		
		//Collect User Input for Cuboid
		System.out.println("Please type the cuboid height and press [Enter]:");
		cuboidHeight = keyboard.nextFloat();
		
		//Validate Height
		while(cuboidHeight <= 0) {
			System.out.println("Please enter a valid cuboid height and press [Enter]:");
			cuboidHeight = keyboard.nextFloat();
		} if (cuboidHeight > 0){
			cuboidHeight = keyboard.nextFloat();
		}
		
		System.out.println("Please type the cuboid width and press [Enter]:");
		cuboidWidth = keyboard.nextFloat();
	
		//Validate Width
		while(cuboidWidth <= 0) {
			System.out.println("Please enter a valid cuboid width and press [Enter]:");
			cuboidWidth = keyboard.nextFloat();
		} if(cuboidWidth > 0) {
			cuboidWidth = keyboard.nextFloat();
	
		} 
		
		System.out.println("Please type the cuboid depth and press [Enter]:");
		cuboidDepth = keyboard.nextFloat();
		
		//Validate Depth
		 while(cuboidDepth <= 0) {
			System.out.println("Please enter a valid cuboid depth and press [Enter]:");
			cuboidDepth = keyboard.nextFloat();
		} if (cuboidDepth > 0) {
			cuboidDepth = keyboard.nextFloat();
			
		}
		 
		//Collect User Input for Cylinder
		System.out.println("Please type the cylinder height and press [Enter]:");
		cylinderHeight = keyboard.nextFloat();
			
		//Validate Height
		while(cylinderHeight <= 0) {
			System.out.println("Please enter a valid cylinder height and press [Enter]:");
			cylinderHeight = keyboard.nextFloat();
		} if(cylinderHeight > 0) {
			cylinderHeight = keyboard.nextFloat();
		}
			
		System.out.println("Please type the cylinder radius and press [Enter]:");
		cylinderRadius = keyboard.nextFloat();
		
		//Validate Radius
		while(cylinderRadius <= 0) {
			System.out.println("Please enter a valid cylinder radius and press [Enter]:");
			cylinderRadius = keyboard.nextFloat();
		} if(cylinderRadius > 0) {
			cylinderRadius = keyboard.nextFloat();
		
		} 
		
		
		//Collect User Input for Sphere
		System.out.println("Please type the sphere radius and press [Enter]:");
		sphereRadius = keyboard.nextFloat();
		
		//Validate Radius
		while(sphereRadius <= 0) {
			System.out.println("Please enter a valid sphere radius and press [Enter]:");
			sphereRadius = keyboard.nextFloat();
		} if(sphereRadius > 0) {
			sphereRadius = keyboard.nextFloat();
		
		} 
		
		
		//Create Objects
		Cuboid cuboid = new Cuboid(cuboidWidth, cuboidDepth, cuboidHeight);
		Cylinder cylinder = new Cylinder(cylinderHeight, cylinderRadius);
		Sphere sphere = new Sphere(sphereRadius);
		
		//Call Render Method Dialog Boxes
		cuboid.render();
		cylinder.render();
		sphere.render();
		
		
		keyboard.close();
		
		
	}	

}
