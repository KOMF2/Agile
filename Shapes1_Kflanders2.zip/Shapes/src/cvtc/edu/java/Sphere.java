package cvtc.edu.java;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Sphere extends Shape{
	
	//Attributes
	private float radius;

	//Dialog box object
			JFrame frame = new JFrame();
	
	//Constructor
	public Sphere(float radius) {
		this.radius = radius;
	}


	//Getters and Setters
	public float getRadius() {
		return radius;
	}


	
	public void setRadius(float radius) {
		this.radius = radius;
	}
	
	
	//Surface Area Method
	@Override
	public float surfaceArea() {
		return (float) (4 * Math.PI * (radius * radius));
	}
			
	//Volume Method
	@Override
	public float volume() {
		return (float) (4/3 * Math.PI * (radius * radius * radius));
	}		
		
		
	//Render Method
	@Override
	public void render() {
		//Message box
		JOptionPane.showMessageDialog(frame, "Sphere Dimensions: Radius= " + 
		this.radius + " Volume: " + this.volume() + " Surface Area: " + this.surfaceArea());
	}
	
}
