package cvtc.edu.java;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Cylinder extends Shape{
	
		//Attributes
		private float radius;
		private float height;
		
		//Dialog box object
		JFrame frame = new JFrame();
		
		//Constructor
		public Cylinder(float radius, float height) {
			this.radius = radius;
			this.height = height;
		}


		//Getters and Setters
		public float getRadius() {
			return radius;
		}


		public void setRadius(float radius) {
			this.radius = radius;
		}


		public float getHeight() {
			return height;
		}


		public void setHeight(float height) {
			this.height = height;
		}
		
		//Surface Area Method
		@Override
		public float surfaceArea() {
			return (float) (2 * Math.PI * (radius * radius));
		}
		
		//Volume Method
		@Override
		public float volume() {
			return (float) (Math.PI * (radius * radius) * height);
		}
		
		//Render Method
		@Override
		public void render() {
			//Message box
			JOptionPane.showMessageDialog(frame, "Cylinder Dimensions: Height= " + this.height + " Radius= " + 
			this.radius + " Volume: " + this.volume() + " Surface Area: " + this.surfaceArea());
		}
	
}
