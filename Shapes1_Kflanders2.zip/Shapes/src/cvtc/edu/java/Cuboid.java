package cvtc.edu.java;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Cuboid extends Shape{

	//Attributes
	private float width;
	private float height;
	private float depth;
	
	//Dialog box object
	JFrame frame = new JFrame();
	
	//Constructor
	public Cuboid(float width, float height, float depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}


	//Getters and Setters
	public float getWidth() {
		return width;
	}



	public void setWidth(float width) {
		this.width = width;
	}



	public float getHeight() {
		return height;
	}



	public void setHeight(float height) {
		this.height = height;
	}



	public float getDepth() {
		return depth;
	}



	public void setDepth(float depth) {
		this.depth = depth;
	}

	//Surface Area Method
	@Override
	public float surfaceArea() {
		return 2*(width*depth) + 2*(depth * height) + 2*(height * width);
	}

	//Volume Method
	@Override
	public float volume() {
		return width * height * depth;
	}

	//Render Method
	@Override
	public void render() {
		//Message box
		JOptionPane.showMessageDialog(frame, "Cuboid Dimensions: Height= " + this.height + " Width= " + 
		this.width + " Depth= " + this.depth + " Volume: " + this.volume() + " Surface Area: " + this.surfaceArea());
		
	}
	
}
