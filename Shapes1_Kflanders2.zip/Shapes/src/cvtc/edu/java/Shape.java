package cvtc.edu.java;

public abstract class Shape {
	
		// Abstract Methods
		public abstract float surfaceArea();
		public abstract float volume();
		public abstract void render();
		
			

	}
